// utils.js
const { spawn } = require('child_process');

/**
 * Ejecuta un comando usando spawn y retorna una promesa.
 * Permite ejecutar comandos externos y capturar su salida.
 * @param {string} command - Comando a ejecutar.
 * @param {Array<string>} args - Argumentos del comando.
 * @returns {Promise<void>}
 */
function runCommand(command, args) {
  return new Promise((resolve, reject) => {
    console.log(`Ejecutando: ${command} ${args.join(' ')}`);
    const proc = spawn(command, args, { shell: true });
    proc.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`);
    });
    proc.stderr.on('data', (data) => {
      console.error(`stderr: ${data}`);
    });
    proc.on('close', (code) => {
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`El comando finalizó con el código ${code}`));
      }
    });
  });
}

module.exports = { runCommand };
