// -------------------- Referencias a Elementos del DOM --------------------
const btnHome        = document.getElementById("btn-home");
const iconDownload   = document.getElementById("icon-download");
const iconVisualize  = document.getElementById("icon-visualize");

const homeScreen     = document.getElementById("home-screen");
const downloadScreen = document.getElementById("download-screen");
const visualizeScreen= document.getElementById("visualize-screen");
const modulesScreen  = document.getElementById("modules-screen");
const lessonsScreen  = document.getElementById("lessons-screen");
const playerScreen   = document.getElementById("player-screen");

const downloadForm   = document.getElementById("download-form");
const downloadNotifications = document.getElementById("download-notifications");
const coursesGrid    = document.getElementById("courses-grid");
const modulesList    = document.getElementById("modules-list");
const lessonsList    = document.getElementById("lessons-list");

const videoElement   = document.getElementById("video-element");
const btnPlayPause   = document.getElementById("btn-play-pause");
const btnPrev        = document.getElementById("btn-prev");
const btnNext        = document.getElementById("btn-next");
const timeSlider     = document.getElementById("time-slider");
const btnSubtitles   = document.getElementById("btn-subtitles");
const btnMute        = document.getElementById("btn-mute");
const volumeSlider   = document.getElementById("volume-slider");
const btnFullscreen  = document.getElementById("btn-fullscreen");

// Elementos para mostrar la información en modo reproducción
const lessonTitle    = document.getElementById("lesson-title");
const moduleTitle    = document.getElementById("module-title");
const courseTitle    = document.getElementById("course-title");

// Variable para WebSocket
let socket;

// Variables globales para la navegación entre lecciones
let currentCourseName = "";
let currentModuleName = "";
let currentLessons = [];
let currentLessonIndex = 0;

// -------------------- Funciones Auxiliares --------------------
function hideAllScreens() {
  document.querySelectorAll('.screen').forEach(screen => screen.classList.remove('active'));
}

/**
 * Detiene la reproducción del video y sale del modo "playing".
 * - Pausa el video
 * - Limpia el src
 * - Quita la clase "playing" del body
 */
function stopPlayback() {
  if (document.body.classList.contains("playing")) {
    videoElement.pause();
    videoElement.src = "";
    videoElement.load();
    document.body.classList.remove("playing");
  }
}

// Inicializar WebSocket y manejar mensajes
function initWebSocket() {
  socket = new WebSocket('ws://localhost:8090');

  socket.onopen = () => {
    console.log("WebSocket conectado");
  };

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data);
      console.log("Mensaje recibido:", data);

      // Si el servidor envía la lista de cursos
      if (data.status === "courses_list") {
        renderCourses(data.courses);
      }

      // Si el servidor envía un mensaje de error
      if (data.status === "error") {
        console.error("Error desde el servidor:", data.message);
      }

      // Manejar otros estados (descargando, progreso, etc.)
      if (data.status === "downloading") {
        if (downloadNotifications) {
          downloadNotifications.textContent = `Descargando... ${data.progress}% completado. Tiempo restante: ${data.timeRemaining}`;
        }
      }
      if (data.status === "completed") {
        if (downloadNotifications) {
          downloadNotifications.textContent = "Descarga completada.";
        }
      }

    } catch (error) {
      console.error("Error al parsear el mensaje:", error);
    }
  };

  socket.onerror = (error) => {
    console.error("WebSocket error:", error);
  };
}

// -------------------- Modo Streaming: Auto-ocultación de Controles --------------------
let controlsTimeout;
function setupAutoHideControls() {
  const header = document.querySelector("header");
  const footer = document.querySelector("footer");
  const playerInfo = document.querySelector("#player-info");

  header.classList.remove("hide-controls");
  footer.classList.remove("hide-controls");
  playerInfo.classList.remove("hide-controls");

  clearTimeout(controlsTimeout);
  controlsTimeout = setTimeout(hideControls, 3000);
}

function hideControls() {
  document.querySelector("header").classList.add("hide-controls");
  document.querySelector("footer").classList.add("hide-controls");
  document.querySelector("#player-info").classList.add("hide-controls");
}

function showControlsOnInteraction() {
  document.querySelector("header").classList.remove("hide-controls");
  document.querySelector("footer").classList.remove("hide-controls");
  document.querySelector("#player-info").classList.remove("hide-controls");

  clearTimeout(controlsTimeout);
  controlsTimeout = setTimeout(hideControls, 3000);
}

document.addEventListener("mousemove", () => {
  if (document.body.classList.contains("playing")) {
    showControlsOnInteraction();
  }
});
document.addEventListener("touchstart", () => {
  if (document.body.classList.contains("playing")) {
    showControlsOnInteraction();
  }
});

// -------------------- Navegación entre Pantallas --------------------
// Clic en el nombre de la app → pantalla de inicio
btnHome.addEventListener("click", () => {
  stopPlayback();
  hideAllScreens();
  homeScreen.classList.add("active");
});

// Ícono de Descargar → pantalla de descarga
iconDownload.addEventListener("click", () => {
  stopPlayback();
  hideAllScreens();
  downloadScreen.classList.add("active");
});

// Ícono de Visualizar → pantalla de cursos
iconVisualize.addEventListener("click", () => {
  stopPlayback();
  hideAllScreens();
  visualizeScreen.classList.add("active");
  requestCoursesList();
});

// -------------------- Lógica de Descarga --------------------
if (downloadForm) {
  downloadForm.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      alert("WebSocket no conectado. Asegúrate de que el servidor está activo.");
      return;
    }
    const courseUrl     = document.getElementById("course-url").value;
    const subtitleLang  = document.getElementById("subtitle-lang").value;
    const sessionCookie = document.getElementById("session-cookie").value;
    const credentials   = document.getElementById("credentials").value;

    // Enviar acción "download" al servidor
    const message = {
      action: "download",
      courseUrl,
      subtitleLang,
      sessionCookie,
      credentials,
    };
    socket.send(JSON.stringify(message));

    downloadNotifications.classList.add("active");
    downloadNotifications.textContent = "Iniciando descarga...";
  });
}

// -------------------- Solicitar y Renderizar Cursos --------------------
function requestCoursesList() {
  if (!socket || socket.readyState !== WebSocket.OPEN) {
    console.warn("WebSocket no conectado. No se puede solicitar lista de cursos.");
    return;
  }
  socket.send(JSON.stringify({ action: "list_courses" }));
}

/**
 * Muestra los cursos disponibles en la pantalla "visualize-screen".
 */
function renderCourses(courses) {
  if (!coursesGrid) return;
  coursesGrid.innerHTML = "";
  if (!courses || courses.length === 0) {
    coursesGrid.innerHTML = "<p>No hay cursos descargados.</p>";
    return;
  }

  courses.forEach((course) => {
    const card = document.createElement("div");
    card.className = "course-card";
    card.addEventListener("click", () => {
      renderModules(course);
    });

    // Miniatura (ficticia o real)
    const thumb = document.createElement("img");
    thumb.className = "course-thumb";
    thumb.src = "https://picsum.photos/200/100?random=" + Math.floor(Math.random() * 1000);
    thumb.alt = `Miniatura de ${course.name}`;

    const info = document.createElement("div");
    info.className = "course-info";

    const h3 = document.createElement("h3");
    h3.textContent = course.name;

    info.appendChild(h3);
    card.appendChild(thumb);
    card.appendChild(info);
    coursesGrid.appendChild(card);
  });
}

/**
 * Muestra los módulos de un curso en la pantalla "modules-screen".
 */
function renderModules(course) {
  hideAllScreens();
  modulesScreen.classList.add("active");

  modulesList.innerHTML = "";
  if (!course.modules || course.modules.length === 0) {
    modulesList.innerHTML = "<p>Este curso no tiene módulos.</p>";
    return;
  }

  // Para cada módulo, pasamos el nombre del curso a la siguiente función
  course.modules.forEach((mod) => {
    const modItem = document.createElement("div");
    modItem.className = "playlist-item";
    modItem.textContent = mod.name;
    modItem.addEventListener("click", () => {
      renderLessons(mod, course.name);
    });
    modulesList.appendChild(modItem);
  });
}

/**
 * Muestra las lecciones de un módulo en la pantalla "lessons-screen".
 * @param {Object} module - El módulo seleccionado.
 * @param {string} courseName - El nombre del curso al que pertenece este módulo.
 */
function renderLessons(module, courseName) {
  hideAllScreens();
  lessonsScreen.classList.add("active");

  lessonsList.innerHTML = "";
  if (!module.lessons || module.lessons.length === 0) {
    lessonsList.innerHTML = "<p>Este módulo no tiene lecciones.</p>";
    return;
  }

  module.lessons.forEach((lesson, index) => {
    const lessonItem = document.createElement("div");
    lessonItem.className = "playlist-item";
    lessonItem.textContent = lesson.name;
    lessonItem.addEventListener("click", () => {
      // Guardamos la info para el reproductor
      currentCourseName = courseName;
      currentModuleName = module.name;
      currentLessons = module.lessons;
      currentLessonIndex = index;

      playLesson(lesson, module.name, courseName);
    });
    lessonsList.appendChild(lessonItem);
  });
}

/**
 * Reproduce una lección en modo streaming.
 * @param {Object} lesson - La lección (con 'name' y 'file').
 * @param {string} moduleName - El nombre del módulo.
 * @param {string} courseName - El nombre del curso.
 */
function playLesson(lesson, moduleName, courseName) {
  hideAllScreens();
  playerScreen.classList.add("active");

  // Activa el modo de reproducción (estilos especiales para streaming)
  document.body.classList.add("playing");

  // Asigna los textos en el overlay
  if (lessonTitle) lessonTitle.textContent = lesson.name;    // H1
  if (moduleTitle) moduleTitle.textContent = moduleName;     // H2
  if (courseTitle) courseTitle.textContent = courseName;     // H3

  // Configura el video para reproducir la lección
  videoElement.src = lesson.file;
  videoElement.load();

  // Fuerza el audio a estar activado
  videoElement.muted = false;
  isMuted = false;
  volumeSlider.value = 1;

  videoElement.play().catch(err => {
    console.warn("No se pudo reproducir automáticamente:", err);
  });

  // Configura la auto-ocultación de controles
  setupAutoHideControls();
}

// -------------------- Controles de Reproducción (Barra Inferior) --------------------
let isPlaying = false;

btnPlayPause.addEventListener("click", () => {
  if (isPlaying) {
    videoElement.pause();
  } else {
    videoElement.play().catch(err => {
      console.warn("No se pudo reproducir automáticamente:", err);
    });
  }
});

videoElement.addEventListener("play", () => {
  isPlaying = true;
  if (btnPlayPause.tagName === "IMG") {
    btnPlayPause.src = "icons/pause.svg";
  }
});

videoElement.addEventListener("pause", () => {
  isPlaying = false;
  if (btnPlayPause.tagName === "IMG") {
    btnPlayPause.src = "icons/play.svg";
  }
});

/**
 * Botón anterior: Reproduce la lección anterior si existe.
 */
btnPrev.addEventListener("click", () => {
  if (currentLessonIndex > 0) {
    currentLessonIndex--;
    const prevLesson = currentLessons[currentLessonIndex];
    playLesson(prevLesson, currentModuleName, currentCourseName);
  } else {
    alert("No hay lección anterior en este módulo.");
  }
});

/**
 * Botón siguiente: Reproduce la siguiente lección si existe.
 */
btnNext.addEventListener("click", () => {
  if (currentLessonIndex < currentLessons.length - 1) {
    currentLessonIndex++;
    const nextLesson = currentLessons[currentLessonIndex];
    playLesson(nextLesson, currentModuleName, currentCourseName);
  } else {
    alert("No hay más lecciones en este módulo.");
  }
});

// Barra de progreso
timeSlider.addEventListener("input", () => {
  if (videoElement.duration) {
    const pct = parseFloat(timeSlider.value) / 100;
    videoElement.currentTime = pct * videoElement.duration;
  }
});

videoElement.addEventListener("timeupdate", () => {
  if (videoElement.duration) {
    const pct = (videoElement.currentTime / videoElement.duration) * 100;
    timeSlider.value = pct;
  }
});

// Subtítulos
btnSubtitles.addEventListener("click", () => {
  if (videoElement.textTracks && videoElement.textTracks.length > 0) {
    const track = videoElement.textTracks[0];
    track.mode = (track.mode === "showing") ? "disabled" : "showing";
    alert(`Subtítulos: ${track.mode === "showing" ? "Activados" : "Desactivados"}`);
  }
});

// Sonido / silencio
let isMuted = false;
btnMute.addEventListener("click", () => {
  isMuted = !isMuted;
  videoElement.muted = isMuted;
  if (btnMute.tagName === "IMG") {
    btnMute.src = isMuted ? "icons/mute.svg" : "icons/volume.svg";
  }
});

// Volumen
volumeSlider.addEventListener("input", () => {
  videoElement.volume = parseFloat(volumeSlider.value);
  if (videoElement.volume === 0) {
    isMuted = true;
    if (btnMute.tagName === "IMG") btnMute.src = "icons/mute.svg";
  } else {
    isMuted = false;
    if (btnMute.tagName === "IMG") btnMute.src = "icons/volume.svg";
  }
});

// Pantalla completa
btnFullscreen.addEventListener("click", () => {
  if (!document.fullscreenElement) {
    document.documentElement.requestFullscreen();
  } else {
    document.exitFullscreen();
  }
});

// -------------------- Inicialización --------------------
document.addEventListener("DOMContentLoaded", () => {
  // Por defecto, mostrar solo la pantalla de inicio
  hideAllScreens();
  homeScreen.classList.add("active");
  // Inicializar WebSocket
  initWebSocket();
});
